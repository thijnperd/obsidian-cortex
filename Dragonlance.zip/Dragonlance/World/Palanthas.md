 #city #location
 
 >[!info]- Hierarchy
>Palanthas is a city within the county of [[Solamnia]]

Palanthas was praised to be the "jewel of [[Solamnia]]" and is the epicenter of learning in the continent of [[Ansalon]] 