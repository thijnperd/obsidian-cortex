#country #location

>[!info]- Hierarchy
>Solamnia is a country within the continent [[Ansalon]]
