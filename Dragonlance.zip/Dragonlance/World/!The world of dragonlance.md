> [!info] Location Hierarchy
>**World:** [[Krynn]] 
>**Continents:** [[Ansalon]]
>**Countries:** [[Solamnia]], [[Istar]]
>**Villages/towns/cities:** [[Vogler]], [[Palanthas]]
