#country #location 

>[!info]- Hierarchy
>Solomnia is a country within the continent [[Ansalon]]