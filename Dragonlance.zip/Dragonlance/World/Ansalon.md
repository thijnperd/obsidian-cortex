#continent #location

>[!info]- Hierarchy
Ansalon is a continent within the world of [[Krynn]]