#NPC #important #Chapter2

A citizen of [[Vogler]]
Lord Bakaris Uth Estide (neutral evil, human [noble](https://www.dndbeyond.com/monsters/16966-noble)) is an arrogant man with a lesser title among the Solamnic nobility. In ages past, his family was known for its wealth and generations of membership in the Knights of Solamnia. While Lord Bakaris retains a considerable amount of wealth, he has lived his entire life on stories of honor and great deeds, none of which are his own. Now Lord Bakaris sees the situation in Kalaman as his chance to win glory for himself. At heart, he’s comically cowardly, full of bluster and inflated words. He has neither the spine to stand up to opposition nor the experience to lead.

_**Personality Trait.**_ “I was born for greatness, and I’ll take what I deserve.”
_**Ideal.**_ “My brilliance and worthiness are clear to everyone intelligent enough to deserve my time.”
_**Bond.**_ “My deeds will be the grandest chapter in the Estide family legend.”
_**Flaw.**_ “My blood makes me a leader. If commoners can do it, how hard can it be?”
**_Family_:** Father of [[Bakaris the Younger]]
![](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/04-002.bakaris.png)