#NPC #unimportant #Chapter1

> [!quote] Pronounciation
> TH-an

A citizen of [[Vogler]]
Middle aged man Than (chaotic good, kender [commoner](https://www.dndbeyond.com/monsters/16829-commoner)).
**Background & Job:** Vogler's resident tinker gnome, A friend of [[Becklin Uth Viharin]] and [[Darrett Highwater]]
**Trait:** Than occasionally drops by to fine-tune this device, called a gnomeflinger.

---
###### About the gnomeflinger
Though it looks like a weapon of war, the contraption is a mode of rapid transportation originally devised by the tinker gnomes of Mount Nevermind.
Becklin tolerates the gnomeflinger—and the noise of Than’s occasional early-morning tinkering—because she sees the catapult-shaped device as a deterrent against attack.

>[!info]- Gnomeflinger
_Large Object_
**Armor Class:** 15
**Hit Points:** 100
**Damage Immunities:** poison, psychic
The gnomeflinger is a catapult designed to hurl creatures, instead of projectiles, in a high arc. The gnomeflinger was designed in conjunction with the [narycrash](https://www.dndbeyond.com/equipment/349-narycrash) (see the [“Adventuring Gear”](https://www.dndbeyond.com/sources/dnd/sotdq/gear-and-magic-items#AdventuringGear) section) to hasten transportation. The device can hold one Medium or smaller creature. Before it can be used, the gnomeflinger must be loaded and aimed. It takes 1 action to load the gnomeflinger, 1 action to aim it, and 1 action to fire it.
While taking an action to aim the gnomeflinger, you set the maximum horizontal distance of the Fling Personnel action to 60 feet, 150 feet, or 300 feet.
_**Fling Personnel.**_ The gnomeflinger catapults a Medium or smaller creature at least 60 feet away horizontally, with a maximum horizontal distance of 60 feet, 150 feet, or 300 feet, depending on the option chosen when the catapult was aimed. During this trajectory, the creature always reaches a height of 60 feet vertically.
A creature that collides with another creature or an object during this trajectory takes 3 (1d6) bludgeoning damage for every 10 feet away from the gnomeflinger it is.
