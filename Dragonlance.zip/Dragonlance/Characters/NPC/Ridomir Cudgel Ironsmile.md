#NPC #semi-important #Chapter1

> [!quote] Pronounciation
> rid-OH-mere "CUD-gel" EYR-on-smile
#### Ridomir “Cudgel” Ironsmile
Cudgel Ironsmile (neutral, hill dwarf [veteran](https://www.dndbeyond.com/monsters/17045-veteran)) hails from the dwarven nation of Kayolin, south of Solamnia. For most of her life, she adventured with Becklin and Ispin, earning the nickname Cudgel along the way. She now commands her own company of mercenaries known as the Ironclad Regiment. Though small, the company has built a reputation for beating the odds, thanks in large part to her adroit leadership. Beyond a life of fighting, the middle-aged dwarf is a gifted card player. She also has a soft spot for Vogler, which she swears serves the best fish pies in Solamnia.

_**Personality Trait.**_ “The person with the loudest voice usually wins the argument.”
_**Ideal.**_ “I like a well-thought-out plan, but a well-executed one is sublime.”
_**Bond.**_ “Money motivates, but the right cause inspires.”
_**Flaw.**_ “I can be slow to leave the comforts of an inn or tavern.”