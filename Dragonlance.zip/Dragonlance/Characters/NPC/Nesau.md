#NPC #unimportant #Chapter1 

> [!quote] Pronounciation
> ne-SAW

A citizen of [[Vogler]]
Young aged man (chaotic neutral, human [commoner](https://www.dndbeyond.com/monsters/16829-commoner))
**Job:** Substitute wharfinger of Vogler
**Trait:** Is quick to forgive fines and forgo docking fees when his father isn’t present, making him quite popular in the village.
**Family:** son of [[Umpton Lanth]]