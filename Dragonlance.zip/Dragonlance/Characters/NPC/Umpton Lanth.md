#NPC #unimportant #Chapter1 

> [!quote] Pronounciation
> ump-TON Lan-th

A citizen of [[Vogler]]
Middle aged man (lawful neutral, human [guard](https://www.dndbeyond.com/monsters/16915-guard))
**Background:** Fishers and traders seeking to use the wharf must register with Umpton at his stuffy two-story office across from the market.
**Job:** Wharfinger of Vogler
**Trait:** Wakes up earlier than any other fisher in Vogler to inspect boats docked at the wharf and impose fines on those in poor repair.
**Family:** Father of [[Nesau]]