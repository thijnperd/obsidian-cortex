#NPC #unimportant #Chapter1

> [!quote] Pronounciation
> el-THAR

A citizen of [[Vogler]]
Elderly man Elthar (neutral good, human [commoner](https://www.dndbeyond.com/monsters/16829-commoner)).
**Background & Job:** Proprietor of the Vogler restaurant, The fishbowl
**Trait:** Most locals seem to call him uncle

>[!info]- Statsheet
Medium Humanoid (Any Race), Any Alignment
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
Armor Class 10
Hit Points 4 (1d8)
Speed 30 ft.
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
STR: 10 (+0)
DEX: 10 (+0)
CON: 10 (+0)
INT: 10 (+0)
WIS: 10 (+0)
CHA: 10 (+0)
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
**Senses** 
Passive Perception: 10
Languages Any one language (usually Common)
Challenge 0 (10 XP)
Proficiency Bonus +2
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
**Actions**
_**Club.** Melee Weapon Attack:_ +2 to hit, reach 5 ft., one target. _Hit:_ 2 (1d4) bludgeoning damage.

