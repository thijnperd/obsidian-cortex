#NPC #important #Chapter1 

>[!quote] Pronounciation
>DARE-et HIGH-wah-ter

A citizen of [[Vogler]]
Darrett Highwater (lawful good, human [knight](https://www.dndbeyond.com/monsters/16938-knight)) is a fastidious, aspiring knight who serves [[Becklin Uth Viharin]]. His parents abandoned him in town over a decade ago, after which Darrett spent years as a ward of the community before coming under Becklin’s wing. In the years since, his good heart and aptitude for strategic thinking led Becklin to train him for induction into the Knights of Solamnia one day. 
Darrett is well-read and courteous, though he sometimes catches himself talking in ways he considers less than knightly, for which he apologizes profusely.

_**Personality Trait.**_ “My mind sometimes works faster than I can talk, and I often second-guess myself.”
_**Ideal.**_ “My honor is my life.”
_**Bond.**_ “As Becklin’s student, I’m trying to learn everything I can from such a hero.”
_**Flaw.**_ “Though I understand military strategy, I’m inexperienced at command and have a hard time delegating.”

>[!info] Darrett and Becklin
>Darrett Highwater is Becklin’s pupil, though Becklin would refers to him privately as her squire. As much as Darrett respects Becklin and hopes to one day become a true Knight of Solamnia, he knows the people of Vogler frown on the knighthood and would see his aspirations as naive fantasies.


![278](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-005.darrett-highwater.png)
