#NPC #semi-important #Chapter1 

> [!quote] Pronounciation
> bah-kah-RIS the younger

Bakaris (neutral evil, human [noble](https://www.dndbeyond.com/monsters/16966-noble)) shares the same name as his father, his father’s father, and so on for generations. Bakaris places inordinate value on his good looks, fashionable clothes, and athleticism, but he’s known more for his arrogance, pettiness, and short temper. He cares nothing for his family name, but he defers to his father—partly from unbroken childhood habit, and partly because all his privilege depends on his father’s wealth. Bakaris also has a violent streak. While living in Estwilde, he murdered the son of a local leader during a duel, and he and his father to Vogler to escape the consequences. Bakaris takes quiet pride in that killing, and he fantasizes about one day winning respect via the point of his sword. He loathes being called “the Younger,” a diminutive his father encourages.

_**Personality Trait.**_ “My blood, my looks, my skill; everything about me is better than you.”
_**Ideal.**_ “I’ll force the world to recognize how great I am.”
_**Bond.**_ “I’ve wasted too much time already; I owe it to myself to claim what I deserve.”
_**Flaw.**_ “What I can’t get with my looks, I’ll take with my sword.”
**_Family_:** Son of [[Lord Bakaris Uth Estide]]

[![241](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-004.bakaris-the-younger.png)
>[!info]- Stat Sheet:
>[Noble](https://www.dndbeyond.com/monsters/16966-noble)
Medium Humanoid (Any Race), Any Alignment
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
Armor Class 15 (breastplate)
Hit Points 9 (2d8)
Speed 30 ft.
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
STR: 11 (+0)
DEX: 12 (+1)
CON: 11 (+0)
INT: 12 (+1)
WIS: 14 (+2)
CHA: 16 (+3)
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
**Skills**
[Deception](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills) +5, [Insight](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills) +4, [Persuasion](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills) +5
Senses Passive Perception 12
Languages Any two languages
Challenge 1/8 (25 XP)
Proficiency Bonus +2
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
**Actions**
_**Rapier.** Melee Weapon Attack:_ +3 to hit, reach 5 ft., one target. _Hit:_ 5 (1d8 + 1) piercing damage.
Reactions
_**Parry.**_ The noble adds 2 to its AC against one melee attack that would hit it. To do so, the noble must see the attacker and be wielding a melee weapon.
