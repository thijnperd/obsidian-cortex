#NPC #important #Chapter1 

>[!quote] Pronounciation
>BEK-lin ooth ve-HAR-in
#### Becklin Uth Viharin
A citizen of [[Vogler]]
Becklin Uth Viharin (lawful good, human [knight](https://www.dndbeyond.com/monsters/16938-knight)) is a Solamnic Knight of the Order of the Crown who, in her earlier years, adventured with Ispin Greenshield and Cudgel Ironsmile. For the last decade, she has served as castellan of Thornwall Keep in Vogler. This posting is not only an official charge from her superiors but also a quiet retirement for her. Becklin takes her role seriously, maintaining her skills and equipment as she remains alert for danger. In her considerable free time, she indulges her passion for studying the past by excavating the ruins of Thornwall Keep.

The region’s commonfolk generally don’t hold the Knights of Solamnia in high regard, most believing the knights had a hand in causing—or, at least, not preventing—the Cataclysm. However, the people of Vogler accept Becklin, as her skill at arms has kept the village safe from bandits and dangerous beasts for years.

_**Personality Trait.**_ “Did you know Vogler was an island before the Cataclysm? Let me tell you about it!”
_**Ideal.**_ “We can learn much from the past if we look for it.”
_**Bond.**_ “My honor was my life. It’s still important to me, but no code accounts for all the challenges of living.”
_**Flaw.**_ “I romanticize the past. That’s when people had the chance to become legends.”

![03-002.berklin-uth-viharin.png|199](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-002.berklin-uth-viharin.png)