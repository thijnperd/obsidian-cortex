#NPC #unimportant #Chapter1

> [!quote] Pronounciation
> RAY-ven ooth VOG-ler

A citizen of [[Vogler]]
Woman in her 30s (neutral good, human [scout](https://www.dndbeyond.com/monsters/17007-scout))
**Background:**  Lives in a two-story house on the village circle.  She keeps a pair of guest rooms—lavishly decorated with mounted fish—where she frequently hosts villagers going through tough times.
**Job:** Major of Vogler
**Trait:** Raven is a practical, empathetic leader in who grew up on the river.
