#NPC #important #Chapter0

> [!quote] Pronounciation
> ISS-pin GREEN-shield

Before retiring to the village of [[Vogler]], Ispin Greenshield traveled across [[Ansalon]] as a teacher, trader, and adventurer. Along the way, he forged friendships with each of the characters. Each character knows the following information about him:
- Ispin was a good-natured human adventurer from [[Solamnia]].
- Ispin took his name from a distinctive green shield he found early in his adventuring career. He claimed the shield was magical, but it had no obvious magical properties.
- The bighearted Ispin loved telling tall tales of his travels to anyone who would listen.
- Ispin used to adventure with a human Knight of Solamnia named [[Becklin Uth Viharin]] and a hill dwarf warrior named Cudgel. These two featured in many of Ispin’s stories of fighting sea monsters and goblin raiders.
- Ispin retired from traveling years ago, becoming a permanent resident of a little-known village in Solamnia called Vogler.

The Meeting Ispin Greenshield table suggests a few ways characters might have come to know and likely respect Ispin. Players can elaborate on these connections however they’d like. Characters can use their relationship with Ispin to reinforce how they know one another.

### Meeting Ispin Greenshield
| d6  | Experience                                                                                                               |
| --- | ------------------------------------------------------------------------------------------------------------------------ |
| 1   | Ispin was a close friend of one of your parents. You’ve known him since you were a child.                                |
| 2   | You and Ispin defended a community from a notorious band of goblin raiders.                                              |
| 3   | Ispin tracked you down to return something precious that a thief stole.                                                  |
| 4   | Ispin visited your homeland, bringing with him goods and stories from far-off lands. He taught you much about the world. |
| 5   | Ispin spent a season with your family and taught you swordplay, sailing, a language, or another skill.                   |
| 6   | You and Ispin once competed for the same person’s affections, only to discover each other’s friendship.                  |

### Invitation to a Funeral
Ispin Greenshield wished to have his life celebrated in a simple way, with friends from the lands he traveled joining for festivities and sharing stories. Upon Ispin’s death, his friend Becklin Uth Viharin, a Solamnic knight stationed in Vogler, sought to fulfill Ispin’s wish and sent each of the characters a copy of the letter presented as handout 2.1.

Each character has agreed to attend Ispin’s funeral and has set off on the road to Vogler. The extent of this undertaking might vary for each character. Characters who travel by sea disembark at the port of Kalaman (detailed in [chapter 4](https://www.dndbeyond.com/sources/sotdq/shadow-of-war#KalamanHarbor)) and then travel by road to Vogler. The characters’ travels are largely uneventful until the final leg of their journey (see the “[Preludes](https://www.dndbeyond.com/sources/dnd/sotdq/prelude-to-war#Preludes)” section). [Chapter 3](https://www.dndbeyond.com/sources/sotdq/when-home-burns/) gives characters who have not been traveling together the opportunity to reunite and share details of their journeys.

[![](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/02-003.becklins-letter.png)](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/02-003.becklins-letter.png)