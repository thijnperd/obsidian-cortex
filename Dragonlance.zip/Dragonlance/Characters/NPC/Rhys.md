#NPC #semi-important #Chapter0

> [!quote] Pronounciation
> rh-EES

Rhys is a small character who first appears in the first part of the prelude: [[Part 1; Frantic farmer]]
#### Background & Job
- **Local Farmhand:** Rhys is a regular working-class civilian who lives and works on a farm near the village of Vogler.
- **Hired Stable Boy:** He was recently hired by a trio of Solamnic soldiers specifically to travel with them and care for their horses.
- **Complete Lack of Military Knowledge:** He has absolutely no combat training, does not understand military affairs, and knows nothing about the broader political or magical conflicts brewing on Krynn.

>[!info]- Statsheet
Medium Humanoid (Any Race), Any Alignment
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
Armor Class 10
Hit Points 4 (1d8)
Speed 30 ft.
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
STR: 10 (+0)
DEX: 10 (+0)
CON: 10 (+0)
INT: 10 (+0)
WIS: 10 (+0)
CHA: 10 (+0)
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
**Senses** 
Passive Perception: 10
Languages Any one language (usually Common)
Challenge 0 (10 XP)
Proficiency Bonus +2
![](https://www.dndbeyond.com/file-attachments/0/579/stat-block-header-bar.svg)
**Actions**
_**Club.** Melee Weapon Attack:_ +2 to hit, reach 5 ft., one target. _Hit:_ 2 (1d4) bludgeoning damage.
