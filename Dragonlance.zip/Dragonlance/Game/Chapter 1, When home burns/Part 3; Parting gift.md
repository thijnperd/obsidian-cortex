#story 

The morning after Ispin’s funeral, the characters can take Becklin up on her invitation to Thornwall Keep. They have plenty of time to visit in the morning, as the Kingfisher Festival celebrations don’t kick off until midday.
### Meeting Darrett
As the characters head across town toward Thornwall Keep, they meet Becklin’s squire, [[Darrett Highwater]], along the way. Read or paraphrase the following:

The town is abuzz with festive energy this morning as locals set up stalls and hang decorations. Ahead, the road to Thornwall Keep climbs a low hill toward an ancient edifice, ghostly in the morning mist.

```
“Good morning, Becklin’s friends,” comes a cheerful voice. “I’m glad I caught you.” From a shop doorway steps a young man, no more than twenty years old. He has a sword at his hip and a cloth sack in his arm. “I’m Darrett, Becklin’s student. I hope you haven’t had breakfast already.”
```

Becklin sent Darrett to fetch baked hand pies from the Fishbowl for the two of them and their guests. He encourages the characters to come with him on his errand. Darrett gets few opportunities to speak with travelers and is eager to do so, but he doesn’t press if the characters want to go straight to Thornwall Keep.

>[!info] joining Darret on a walk
>If the characters join him on the short walk, Darrett tells them he grew up in Vogler. He peppers the characters with questions about themselves, their travels, their weapons, and anything else about the world beyond Vogler. He knows all about the Kingfisher Festival and shares the following details:
-The annual festival celebrates the victory of a Knight of Solamnia, Lord Decater Vogler, over the forces of the Empire of Istar. This battle occurred hundreds of years ago, long before the Cataclysm, and sparked the village’s founding.
-Today’s festivities include music, food, and games associated with the town’s founding.
-Mercenaries of the Ironclad Regiment—Cudgel Ironsmile’s band—are training Vogler’s small militia. They’re also participating in a reenactment of the Battle of High Hill this afternoon.

Once Darrett stops at the Fishbowl and purchases hand pies for everyone, he leads the characters to Thornwall Keep.

>[!info] Establishing Darrett 
>Throughout this adventure, Darrett will be the characters’ earnest friend and ally. He’s clever, eager to please, and a little starstruck by the characters. He always has their best interests in mind. Portray him as reliable and with whatever quirks your players are likely to find charming. Establish Darrett’s trustworthiness now so the characters know they can rely on him when it matters later.

[![](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-005.darrett-highwater.png)](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-005.darrett-highwater.png)


### Thornwall Keep

Veins of bronze-colored ivy cling to Thornwall Keep’s ancient three-story stone tower, the tallest structure in Vogler. From its crenelated roof rises an elaborate device resembling a catapult. Crumbling ruins of walls and other fallen structures surround the keep, and amid them lie several shallow square pits and covered excavation sites.

Though it’s no longer a working fortress, Thornwall Keep remains a sturdy structure and an emblem of Vogler’s past. As the characters arrive, Becklin meets them at the door in a simple shirt and breeches, welcoming them inside to her first-floor library.

If Darrett is with the characters, he distributes the hand pies he bought for breakfast. If he’s not, he arrives soon after the characters and does the same. Becklin readily makes small talk about the keep, the excavations she’s conducting on the grounds, and the device on the roof—all detailed in the “[[Vogler]]” section.

#### The Green Shield

After their breakfast, Becklin steps away to her quarters for a moment. When she returns, read the following:

Becklin reenters the room carrying a shallow wooden box, approximately three feet to a side. She sets it down gently on a table. “Ispin left this for all of you,” she explains. “But it comes with a condition. Since he won’t be attending the Kingfisher Festival this year, he wanted you all to participate for him. Specifically, he hoped you’d take his place during the reenactment of the Battle of High Hill. Every year, he looked forward to participating—and dying—in an even more ludicrous way than the year before.”

Becklin smiles at the memory as she opens the box, revealing a round green shield.

The box contains Ispin’s signature shield, a [+1 shield](https://www.dndbeyond.com/magic-items/4753-shield-1) carved with a scarred broadleaf tree and painted a mossy green. The characters all recall hearing Ispin’s story of being given the shield by a unicorn in the far-off forest of Darken Wood. None can say if this is true or another of Ispin’s tall tales.

Becklin gives the characters the shield only if at least one of them agrees to participate in the Battle of High Hill reenactment. She leaves it to the group to decide which character keeps the shield or how they share it.

If the characters have been pleasant, Becklin is happy to chat some more before she tells them she has to prepare for the Kingfisher Festival. Darrett eagerly suggests going to the festival alongside the characters.

>[!warning] Notes on using the book
>From now on I will probably just use the book
