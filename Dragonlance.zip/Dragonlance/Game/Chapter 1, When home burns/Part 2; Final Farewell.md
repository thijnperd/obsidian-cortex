#story
Once the characters have reconnected with one another and explored Vogler to their liking, it’s time to assemble at the Brass Crab for the funeral of Ispin Greenshield. Becklin Uth Viharin, who sent the characters their funeral invitations, catches up to the characters prior to the funeral.

### Meeting Becklin
Becklin is hard to miss, as she’s dressed in the full-plate armor and horned helmet of the Knights of Solamnia. Though she’s never met the characters before, she recognizes one or more of them from Ispin’s descriptions. Becklin introduces herself, offers her condolences, and invites the characters to come with her to the Brass Crab if they aren’t already there. She explains that the service is meant to be a celebration of Ispin’s life, and people will be encouraged to share over-the-top stories about him—like the inflated tales he was known for sharing.

[![](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-002.berklin-uth-viharin.png)](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-002.berklin-uth-viharin.png)

[[Becklin Uth Viharin]]

### Sending Off a Friend
[![](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-003.cudgel-and-becklin.png)](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-003.cudgel-and-becklin.png)
>[!info] image description:
> [[Ridomir “Cudgel” Ironsmile]] and [[Becklin Uth Viharin]] send off their friend [[Ispin Greenshield]]

The funeral takes place at dusk on the stage and dock extending from the rear of the Brass Crab. Becklin encourages the characters to linger near the dock, while many mourning locals in small fishing craft assemble in the nearby water. When you’re ready for the funeral to begin, Becklin takes the stage next to a simple boat, within which rests the body of Ispin Greenshield. Read or paraphrase the following:

Those who were closest to Ispin Greenshield gather on the dock overlooking the Vingaard River. There, Ispin’s body rests in a small boat, his body wrapped in a shroud. A musician plays a soft song as the knight Becklin Uth Viharin steps forward in her ornate Solamnic armor. She smiles gently at those assembled, and her voice carries clearly across the water.

“You all knew Ispin as a friend, and there were none like him. Before he died, he told me this: ‘There should be tales, not tears, for an old scoundrel like me. Make sure everyone knows my stories when I head off on the greatest adventure of them all.’”

Becklin nods, and villagers carry the boat containing Ispin’s body to the dock’s edge, where she and Cudgel lowered it into the water. “So, let us do just that,” Becklin continues as the tiny vessel drifts out onto the Vingaard River. “On the eve of the Kingfisher Festival, we celebrate you, Ispin. Good travels, friend. Until we meet again.”

With that, the boat bearing Ispin’s body drifts down the river and eventually out of sight. After a moment of silence, Becklin invites all assembled into the Brass Crab for a reception and opportunity to share stories about the departed.

### Tales Remembered
The funeral reception is a simple but crowded affair. [[Yalme]], the Brass Crab’s proprietor, keeps bread, cheese, and local ale coming for the dozens of attendees. Practically everyone in the village makes an appearance at the reception, and the characters can find anyone they’ve already met in the village with whom they might want to talk.

Soon after the reception begins, Becklin calls for everyone’s attention and shares one of Ispin’s favorite stories: the tale of the time the High Sub-Senior Artillerist of Mount Nevermind launched her pet weasel all the way from the gnome enclave to Sancrist Island, then hired Ispin to recover the critter—or, at least, to note its trajectory. Becklin tells several other charming stories about Ispin, then invites attendees to share other tales Ispin might have told them.

Characters are invited to participate in this comic tale telling. They’re welcome to improvise their own tales about Ispin, taking cues from what they know about their relationship with the adventurer (as determined in [chapter 2](https://www.dndbeyond.com/sources/sotdq/prelude-to-war#IspinGreenshield)). The crowd nods along to nearly any tale a character tells, whether hearing it for the first or the thousandth time. If you or a player wants a story prompt, roll on or choose an option from the Ispin’s Stories table. Award [inspiration](https://www.dndbeyond.com/compendium/rules/phb/personality-and-background#Inspiration) to characters who tell a particularly creative or touching story.

#### Ispin’s Stories
| d6  | Story                                                                                                                                                                               |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | For three days, a trireme crewed by minotaur pirates had been chasing Ispin’s ship across the Blood Sea of Istar, when finally...                                                   |
| 2   | Ispin spent the night in a roc’s nest high in the Vingaard Mountains, but when the sun rose...                                                                                      |
| 3   | The Lord of [[Palanthas]] ordered Ispin arrested after the adventurer shaved the lord’s twin Solamnic poodles, but Ispin talked his way out of it by...                             |
| 4   | Ispin weathered a week locked in the dungeons of the mountain dwarf nation of Kayolin, but he secured his release by promising to...                                                |
| 5   | One night, Ispin shared a campfire with a befuddled old man who disappeared before dawn, never to be seen again. Ispin always remembered the strange advice the traveler offered... |
| 6   | Once, Ispin saved an entire village by using his shield to...                                                                                                                       |

### Heckler
During the storytelling, after one or two characters or others have told tales, a finely dressed local named [[Bakaris the Younger]] lets out an exaggerated yawn. If left to continue, he eventually blurts out, “We’ve heard this a thousand times!” or “You’re telling it worse than he did!” 
Bakaris cares nothing for Ispin’s death or the locals’ mourning—he’s only here for the free ale, which he claims is the worst he’s ever tasted. The other mourners grumble, but nobody directly confronts the heckler.

[![](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-004.bakaris-the-younger.png)](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/03-004.bakaris-the-younger.png)

>[!info] Establishing Bakaris 
>Use this interaction to establish Bakaris the Younger as a cowardly cad. He and his father are local annoyances, and they’ll further antagonize the characters later in the adventure. This encounter with Bakaris shouldn’t come to violence, but it should give the characters an accurately negative impression of him.

>[!info] Confronting the Heckler 
>A character who confronts Bakaris the Younger can convince him to stay quiet by roleplaying or succeeding on a DC 12 Charisma ([Intimidation](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills) or [Persuasion](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills)) check. After any confrontation, Bakaris the Younger scoffs and complains no one in Vogler can take a joke, then leaves of his own volition.


### Meeting Cudgel
During the funeral reception, [[Ridomir “Cudgel” Ironsmile]] jovially introduces herself to the characters as an old friend of Ispin Greenshield and the leader of the Ironclad Regiment—mercenaries currently camped outside Vogler. Cudgel asks the characters how they knew Ispin and where they traveled from. She talks openly about herself and her plans to participate in tomorrow’s reenactment of the Battle of High Hill. Cudgel has no agenda other than to chitchat with out-of-town guests, as they likely have more in common with her than the local fishers. Early in the evening, Cudgel excuses herself to check on her company at the [mercenary camp](https://www.dndbeyond.com/sources/dnd/sotdq/when-home-burns#MercenaryCamp) (detailed in the “[Vogler Gazetteer](https://www.dndbeyond.com/sources/dnd/sotdq/when-home-burns#VoglerGazetteer)” section).
### Mysterious Mourner
A particularly somber guest—a blue-skinned Silvanesti elf named [[Leedara]]—keeps to the fringes of the reception. No one in town knows anything about her except her name, that she arrived a day before the characters, and that she claims to be a performer who knew Ispin. Characters who approach Leedara find her politely aloof and evasive about how she knew Ispin—yet she expresses sympathy for the characters, claiming she’s lost many loved ones in her long life. A character can convince Leedara to perform by succeeding on a DC 16 Charisma ([Persuasion](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills)) check, in which case she sings a heartbreakingly beautiful Silvanesti song in Elvish. Soon after, Leedara leaves the reception, retiring to her room in the inn.

>[!info] important info about Leedara
>Leedara has a role to play later in the adventure (see [chapters 4](https://www.dndbeyond.com/sources/sotdq/shadow-of-war#LeedarasWarning) and [chapter7](https://www.dndbeyond.com/sources/sotdq/siege-of-kalaman#S2Entry)). Use this scene to introduce this mysterious character, but don’t reveal anything of her agenda.

### After the Funeral
After each character who wants to has shared a story or mingled with the locals, the reception winds down. Before the characters retire for the evening, Becklin approaches, thanks them for coming, and says she has something Ispin left for them. She won’t say what it is but asks the characters to call on her at Thornwall Keep in the morning.

The story continues in [[Part 3; Parting gift]]