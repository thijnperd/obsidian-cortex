#story
Rhys leads the characters down the road. Once they approach the place where Rhys and the soldiers were ambushed, Rhys refuses to go any farther. He tells the characters the soldiers should be just ahead.

The ambush site is a few hundred feet ahead. Read the following text when the characters arrive:

```
A wrecked wagon lies toppled, surrounded by armored corpses. Strange figures pick through the remains. From beneath the figures’ dark cloaks jut scaly wings and sharp, reptilian features
```

>[!info] About the enemies
>The mysterious raiders are a [kapak draconian](https://www.dndbeyond.com/monsters/3081113-kapak-draconian) and four [baaz draconians](https://www.dndbeyond.com/monsters/3081100-baaz-draconian) 
>They wear armor emblazoned with the symbol of Takhisis, which any character can recognize by succeeding on a DC 12 Intelligence ([Religion](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills)) check.

>[!info] Remaining hidden
If the characters want to remain hidden, have them roll Dexterity ([Stealth](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills)) checks against the kapak draconian’s passive Wisdom ([Perception](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills)) score of 13. If the draconians don’t notice the characters, they pick the wagon clean of valuables and leave shortly after.

If the draconians notice the characters, the kapak draconian orders two of the baaz draconians to attack, then slips away with the other two into the surrounding forest. The baaz draconians are battered from the fight with the knights and have half their normal hit points. The retreating draconians won’t fight the characters under any circumstances; they have orders to immediately rejoin the Dragon Army elsewhere and report on the knights’ fate.

_**Murdered Knights.**_ By the time the characters arrive, the three soldiers who hired Rhys have been killed. They are beyond the aid of a [revivify](https://www.dndbeyond.com/spells/2234-revivify) spell. A character who examines the dead soldiers’ armor and succeeds on a DC 12 Intelligence ([History](https://www.dndbeyond.com/sources/dnd/free-rules/playing-the-game#Skills)) check recognizes them as Knights of Solamnia.

>[!info] Searching the knights
If the characters search the remains, they find correspondence that states the knights were investigating reports of nearby farmsteads being raided by strange creatures that match the draconians’ descriptions.

_**Treasure.**_ The three soldiers each wear plate armor with filigree and horned helmets distinctive to Knights of Solamnia, but each suit bears vicious claw marks that make it unusable. Among the wreckage are also three [longswords](https://www.dndbeyond.com/equipment/4-longsword), eight days of food and water for one person, and 40 gp.

#### Conclusion
Shortly after the draconians are defeated, Rhys rejoins the characters and asks them what those monsters were. He has no idea, and the characters likely don’t either. This is one of the first times draconians have made their way into Solamnia, but it won’t be the last.

>[!info] If all goes horribly
If battle turns against the characters, another group of travelers can be heard approaching on the road. Not wanting to risk a larger fight, the wounded draconians retreat, leaving the characters to be saved by these travelers, who are also headed to Vogler.

Continues into the main storyline, starting with "[[Part 1; Arriving in Vogler]]"