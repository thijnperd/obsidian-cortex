#story
All characters are invited to the funeral of their common friend [[Ispin Greenshield]], 

while heading to [[Vogler]] the characters encounter [[Rhys]], a young human [commoner](https://www.dndbeyond.com/monsters/16829-commoner) who barely survived a recent attack on the caravan he was traveling with.

>[!info]- Letter of invitiation
>[![](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/02-003.becklins-letter.png)](https://media.dndbeyond.com/compendium-images/sotdq/kHXEUZ8D0saAJOvE/02-003.becklins-letter.png)

Read or paraphrase the following text to start this prelude:

```
As you travel down the road, you hear quivering scream from around the next corner. “Please, help!” a young man shouts as he rushes around a bend ahead and races toward you.
```

This young man is Rhys. He’s terrified and barely coherent in his frantic pleas for help. 

> [!info] Character calms Rhys down
> 
> If a character spends a minute trying to calm Rhys down, he finally realizes he’s not being chased by anything. Once this happens, Rhys reveals the following information:
> 
-Rhys works at a nearby farm and was hired by a group of soldiers to travel with them and care for their horses.
-Rhys doesn’t know much about the soldiers. He heard them talk about enemy troops supposedly afoot in the region.
-Just moments ago, the soldiers Rhys was with were attacked by black-cloaked figures.
Rhys didn’t get a good look at the cloaked attackers. He hid in the brush and escaped while the soldiers fought them off.

>[!info] Characters are visibly armed
>If the characters are visibly armed, Rhys urges them to help the soldiers, fearing his employers might fall against their attackers. He can lead the characters to where the caravan was attacked, about a half mile down the road.

Rhys doesn’t know this, but the soldiers who hired him weren’t merely solders—they were Knights of Solamnia who were deployed to investigate reports of recent attacks by strange creatures in the region.

---
The prelude continues in [[Part 2; Fallen caravan]]`
