#Enemy #important #Chapter1

Leedara died during the Cataclysm over three hundred years ago. Once an elven priest, Leedara witnessed her companion and fellow priest, Isolde, drawn into the grim fate of the wicked Knight of Solamnia, Lord Loren Soth (detailed in [chapter 4](https://www.dndbeyond.com/sources/sotdq/shadow-of-war#LordSothsCurse)). When Soth failed his gods-given quest to prevent the Cataclysm, he became cursed to exist forever as a death knight. As part of his curse, Leedara and several of her companions returned as deathless spirits devoted to ensuring Soth never finds peace.

Leedara has spent centuries tormenting Lord Soth in his accursed castle, Dargaard Keep, endlessly reminding him of his failures and losses. Now that the Dragon Queen has summoned Soth, Leedara works to stymie the death knight however she can. She followed Soth’s trail to this area and is in Vogler looking for ways to subtly oppose him.

[Leedara](https://www.dndbeyond.com/monsters/3081115-leedara) is neutral-aligned and typically appears as a living Silvanesti elf. She has the statistics of a [ghost](https://www.dndbeyond.com/monsters/16871-ghost) with the following action:

_**Change Shape.**_ Leedara magically assumes the appearance she had in life, and her creature type changes to Humanoid, while retaining her other game statistics. This transformation ends if Leedara is reduced to 0 hit points or uses an action to end it.